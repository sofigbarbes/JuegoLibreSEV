#include "Enemy.h"

Enemy::Enemy(float x, float y, Game* game)
	: EnemyBase( x,  y,  game,"res/enemigo.png") {

	state = game->stateMoving;

	aDying = new Animation("res/animacion_pincho_morir.png", width, height,
		120, 40, 3, 3, false, game);

	aMoving = new Animation("res/animacion_pincho.png", width, height,
		120, 40, 3, 3, true, game);
	animation = aMoving;

	vx = 3;
	vy = 3;
	vxIntelligence = -3;
	vyIntelligence = -3;
	vx = vxIntelligence;

}

void Enemy::update() {
	// Actualizar la animaci�n
	bool endAnimation = animation->update();

	// Acabo la animaci�n, no sabemos cual
	if (endAnimation) {
		// Estaba muriendo
		if (state == game->stateDying) {
			state = game->stateDead;
		}
	}


	if (state == game->stateMoving) {
		animation = aMoving;
	}
	if (state == game->stateDying) {
		animation = aDying;
	}

	// Establecer velocidad
	if (state != game->stateDying) {
		// no est� muerto y se ha quedado parado
		if (vx == 0) {
			vxIntelligence = vxIntelligence * -1;
			vx = -vxIntelligence;
		}
		if (vy == 0) {
			vyIntelligence = vyIntelligence * -1;
			vy = -vyIntelligence;
		}
		if (outRight) {
			// mover hacia la izquierda vx tiene que ser negativa
			if (vxIntelligence > 0) {
				vxIntelligence = vxIntelligence * -1;
			}
			vx = vxIntelligence;
		}
		if (outLeft) {
			// mover hacia la derecha vx tiene que ser positiva
			if (vxIntelligence < 0) {
				vxIntelligence = vxIntelligence * -1;
			}
			vx = vxIntelligence;
		}
	}
	else {
		vx = 0;
		vy = 0;
	}
}




void Enemy::draw(float scrollX) {
	animation->draw(x - scrollX, y);
}

void Enemy::impacted() {
	cout << "Inside Enemy impacted" << endl;
	if (state != game->stateDying) {
		state = game->stateDying;
	}
}

ProjectilEnemigo* Enemy::shoot(Player* player)
{
	return nullptr;
}


