#include "Projectile.h"

Projectile::Projectile(float x, float y, Game* game) :
	Actor("res/projectil__.png", x, y, 20, 20, game) {
}

